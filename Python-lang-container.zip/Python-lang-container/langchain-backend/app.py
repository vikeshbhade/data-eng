from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import os
from dotenv import load_dotenv
import requests

# Load env from .env if present
load_dotenv()

PERPLEXITY_API_KEY = os.getenv("PERPLEXITY_API_KEY")
PERPLEXITY_API_URL = os.getenv("PERPLEXITY_API_URL")

app = FastAPI(title="LangChain Backend")


class PromptRequest(BaseModel):
    prompt: str
    max_tokens: int = 150


@app.get("/health")
async def health():
    return {"status": "ok"}


@app.post("/generate")
async def generate(req: PromptRequest):
    """Generate text for a prompt using Perplexity (HTTP API)."""
    if PERPLEXITY_API_KEY and PERPLEXITY_API_URL:
        try:
            headers = {
                "Authorization": f"Bearer {PERPLEXITY_API_KEY}",
                "Content-Type": "application/json",
            }
            payload = {
                # Adjust fields according to the Perplexity API you target.
                "query": req.prompt,
                "max_tokens": req.max_tokens,
            }
            resp = requests.post(PERPLEXITY_API_URL, headers=headers, json=payload, timeout=30)
            resp.raise_for_status()
            try:
                data = resp.json()
            except ValueError:
                return {"text": resp.text}

            # Heuristically extract text from common fields
            for key in ("answer", "text", "output", "result"):
                if key in data:
                    return {"text": data[key]}
            if isinstance(data.get("answers"), list) and data["answers"]:
                return {"text": data["answers"][0]}
            return {"text": data}
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Perplexity request failed: {e}")

    # Development fallback: echo the prompt
    return {"text": f"(no Perplexity API configured) ECHO: {req.prompt}"}
