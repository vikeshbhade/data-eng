docker build -t langchain-backend:latest ./langchain-backend
docker build -t perplexity-backend:latest ./langchain-backend
LangChain backend (FastAPI)

- `.env.example` contains a template for `PERPLEXITY_API_KEY` and `PERPLEXITY_API_URL`.
- `app.py` exposes `/health` and `/generate` endpoints. `/generate` will call Perplexity via HTTP when `PERPLEXITY_API_KEY` and `PERPLEXITY_API_URL` are set; otherwise it returns a simple echo for development. Note: OpenAI is not used.

To build the Docker image locally:

```bash
# from repository root
docker build -t langchain-backend:latest ./langchain-backend
```

To run without Docker:

```bash
python -m pip install -r langchain-backend/requirements.txt
cp langchain-backend/.env.example .env
# Edit .env and add your PERPLEXITY_API_KEY and PERPLEXITY_API_URL
uvicorn langchain-backend.app:app --reload --port 8000
```
